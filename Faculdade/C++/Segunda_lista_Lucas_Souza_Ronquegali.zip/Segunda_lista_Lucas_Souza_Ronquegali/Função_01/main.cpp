#include "retorneMenor.h"
#include <cstdlib>
#include <iostream>



using namespace std;


int main(int argc, char** argv){

    retorneMenor obj1;
    obj1.leituraValor();
    obj1.retMenor();
    
    return 0;
}

