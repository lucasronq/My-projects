
#ifndef NEGATIVOPOSITIVO_H
#define NEGATIVOPOSITIVO_H

class negativoPositivo {
public:
    negativoPositivo();
    negativoPositivo(const negativoPositivo& orig);
    virtual ~negativoPositivo();
    
    int n;
    
    void lerDados();
    int verificador();
    
    
private:

};

#endif /* NEGATIVOPOSITIVO_H */

