#ifndef CLASSNADADOR_H
#define CLASSNADADOR_H

class classNadador {
public:
    classNadador();
    classNadador(const classNadador& orig);
    virtual ~classNadador();
    
    int idade;
    
    void introNadador();
    int idadeNadador();
    
private:    
    

};

#endif /* CLASSNADADOR_H */

