#include <iostream>
#include <cstdlib>

#include "cardapioSoma.h"

using namespace std;

int main(int argc, char** argv) {
    
    cardapioSoma obj1;
    obj1.cardapioTela();
    obj1.somaTotal();

    return 0;
}

