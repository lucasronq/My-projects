#include "eqSegundoGrau.h"
#include <iostream>
#include <cstdlib>

using namespace std;

eqSegundoGrau::eqSegundoGrau() {
}

eqSegundoGrau::eqSegundoGrau(const eqSegundoGrau& orig) {
}

eqSegundoGrau::~eqSegundoGrau() {
}

void eqSegundoGrau:: lerDados(){
    
    cout << "Entre com o valor de A: ";
    cin >> this-> A;
    cout << "Entre com o valor de B: ";
    cin >> this-> B;
    cout << "Entre com o valor de C: ";
    cin >> this-> C;
    
    cout << "\nO valor de delta é: "<< this->delta();
    
}

float eqSegundoGrau:: delta(){
    
    float result;
    result = 0.0;
    
    result = this->B * this->B - 4*this-> A * this-> C;
    
    return result;
    
}

