#include <cstdlib>

#include "eqSegundoGrau.h"

using namespace std;

int main(int argc, char** argv) {

    eqSegundoGrau *Obj = new eqSegundoGrau();
    Obj->lerDados();
    Obj->delta();
    return 0;
}

