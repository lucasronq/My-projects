#include <cstdlib>
#include <iostream>

#include "classNadador.h"

using namespace std;

int main(int argc, char** argv) {
    
    classNadador obj1;
    obj1.introNadador();
    obj1.idadeNadador();

    return 0;
}

