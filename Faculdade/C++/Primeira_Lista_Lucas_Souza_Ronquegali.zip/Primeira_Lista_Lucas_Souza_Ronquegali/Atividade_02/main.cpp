#include <cstdlib>
#include <iostream>

#include "maiorNumero.h"

using namespace std;

int main(int argc, char** argv) {
    
    maiorNumero obj1;
    obj1.entradaDados();
    obj1.retorneMaior();

    return 0;
}

