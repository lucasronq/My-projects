#include <cstdlib>
#include <iostream>
#include "diasEmAnos.h"

using namespace std;


int main(int argc, char** argv) {
    
    diasEmAnos obj1;
    obj1.leituraDados();
    obj1.calculoTotal();

    return 0;
}

