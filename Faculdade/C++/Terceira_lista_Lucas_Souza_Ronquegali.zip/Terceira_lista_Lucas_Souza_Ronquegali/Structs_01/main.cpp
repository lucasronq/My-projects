#include <cstdlib>

#include "alunosMedia.h"

using namespace std;

int main(int argc, char** argv) {
    
    alunosMedia *Obj = new alunosMedia();
    Obj-> lerDados();

    return 0;
}

