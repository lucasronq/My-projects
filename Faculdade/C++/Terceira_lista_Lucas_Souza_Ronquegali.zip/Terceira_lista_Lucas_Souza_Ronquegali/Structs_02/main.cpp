#include <cstdlib>

#include "calcImc.h"

using namespace std;

int main(int argc, char** argv) {
    
    calcImc *obj1 = new calcImc();
    obj1->lerDados();

    

    return 0;
}

