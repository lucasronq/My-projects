#include <cstdlib>

#include "cpfBusca.h"

using namespace std;


int main(int argc, char** argv) {
    
    cpfBusca *Obj1 = new cpfBusca();
    Obj1->lerDados();

    return 0;
}

