#include <cstdlib>

#include "cadastroBancario.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cadastroBancario *Obj1= new cadastroBancario();
    Obj1->lerDados();


    return 0;
}

