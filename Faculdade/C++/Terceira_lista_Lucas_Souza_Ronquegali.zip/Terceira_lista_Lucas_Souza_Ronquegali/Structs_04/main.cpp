#include <cstdlib>

#include "lojaCadastro.h"

using namespace std;

int main(int argc, char** argv) {
    
    lojaCadastro *obj1 = new lojaCadastro();
    obj1-> lerDados();

    

    return 0;
}

